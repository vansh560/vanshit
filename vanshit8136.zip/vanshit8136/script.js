function viewproject(project Number)
{
    alert('Viewing details for project'+projectNumber);
}